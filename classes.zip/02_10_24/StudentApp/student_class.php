<?php
include_once("htmlLib.php");

class Student{
 public $id;
 public $name;
 public $subject;

 public function __construct($uid,$uname,$usubject)
 {
    $this->id= $uid;
    $this->name=$uname;
    $this->subject=$usubject;
 }

// CRUD
// C = Create 
// R = Read 
// U = Update
// D = Delete

public function save(){
    $data="$this->id,$this->name,$this->subject".PHP_EOL;
    file_put_contents("student_data.txt",$data,FILE_APPEND);
    return "success";
}

public static function dispaly(){
    $data= file("student_data.txt");
    $html="<table>";
    $html.="<tr><th>Id</th><th>Name</th><th>Subject</th><th>Action</th></tr>";
    foreach ($data as $key => $value) {
        $sl=++$key;
        $value=trim($value);
        list($id,$name,$subject)= explode(',', $value);
       
        $delete=actionButton(["action"=>"#","button"=>"Delete ","id"=>"$id","btnName"=>"btnDelete"]);
        $edit=actionButton(["action"=>"update_student.php","button"=>"Edit","id"=>"$id","btnName"=>"btnEdit"]);

     $html.="<tr><td>{$id}</td><td>{$name}</td><td>{$subject}</td><td> $edit $delete</td></tr>";
    }
    $html.="</table>"; 
    return $html;
}


public static function delete($_id){
    $data= file("student_data.txt");
   
    $restOfData="";
    foreach ($data as $key => $value) {
       list($id)=explode(",",$value);
       
       if ($id != $_id) {
        $restOfData.=$value;
       }
    }
    file_put_contents("student_data.txt",$restOfData);
     return "Data Deleted successfully";
}

public static function search($_id){
    $data= file("student_data.txt");
   
    $SearchData=[];
    foreach ($data as $key => $value) {
       list($id,$name,$subject)=explode(",",$value);
       
       if ($id == $_id) {
        $SearchData[]=["id"=>$id, "name"=>$name, "subject"=> $subject];
         break;
       }
    }
    
     return  $SearchData;
}

public function update(){
    $data= file("student_data.txt");
    $updateData="";
    foreach ($data as $key => $value) {
       list($_id,$name,$subject)=explode(",", $value);
       if( trim($_id) == trim($this->id)){
        $updateData.="$this->id,$this->name,$this->subject".PHP_EOL;
       }else{
         $updateData.= "$_id,$name,$subject";
       }
    }
   file_put_contents("student_data.txt",$updateData);
   return true;


}

}



?>