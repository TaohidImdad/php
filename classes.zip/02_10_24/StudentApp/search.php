<?php 
include_once("student_class.php");
if(isset($_POST["btnSearch"])){
    $id=$_POST["search_id"];
    if ( $id != "") {
      $data= Student::search($id);
      //print_r($data);

      echo "
       Id:{$data[0]['id']} <br>
       Name:{$data[0]['name']} <br>
       Subject:{$data[0]['subject']} <br>
      ";

    }
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <a href="index.php">Manage Student</a>
</body>
</html>