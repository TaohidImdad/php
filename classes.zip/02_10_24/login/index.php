<?php 
session_start();

$data=file("admin.txt");
// $_username="admin";
// $_password="123";

if(isset($_POST['btnLogin'])){
    $_username=$_POST["username"];
    $_password=$_POST["password"];
    
foreach ($data as $key => $value) {
   
 list($username,$password,$id)=explode(",", $value);
   if($_username == $username && $_password == $password){

    $_SESSION["uname"]= $_username;
    $_SESSION["id"]= $id;
    $_SESSION['firstname']="Rashed";
    $_SESSION['lastname']="Khan";

    header("location:app.php");
     break;
    }else{
    echo "wrong username or password";
    break;
   }

}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="#" method="post">
        Username <br>
        <input type="text" name="username"> <br>
        Password <br>
        <input type="text" name="password"> <br>

        <button type="submint" name="btnLogin">Login</button>
    </form>
</body>
</html>