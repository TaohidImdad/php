<?php 

class ParentAnimal{
 public function eat(){
    echo "Animal eat food";
 }  
 public function sleep(){
    echo "Animal can sleep";
 }  
}

class Cat extends ParentAnimal{
    
   public function sayHi(){
    echo "meu";
   }

   public function eat(){
    // parent::eat();
     echo "cat eats Fish";
   }

   public static function play(){
      echo "Cat is very playful animal";
   }
}
// $catDanger= new Cat("Halum");
// echo $catDanger->eat();
// echo $catDanger->sayHi();

// $parent= new ParentAnimal();

Cat::play();

?>