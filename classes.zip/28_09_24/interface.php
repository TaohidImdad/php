<?php 

interface Istudent{
     public function study();
     public function play($hours);
}

class Student implements Istudent{
    public function study(){
       echo "An ideal student studies 10h";
    }
    public function play($hours){

    }
}
$student= new Student();
$student->study();






?>