<?php 

class Student{
 public $name;
 public $age;

}

$student1= new Student();
$student1->name="Salam";
$student1->age=26;

$student2= new Student();
$student2->name="Salam";
$student2->age=26;

//print_r($student2);

//echo $student1->name;




class Teacher{
    public $name;
    public $age;
    
    function __construct($uname, $uage)
    {
       $this->name=$uname;
       $this->age= $uage;
    }
   
    public function getName(){
       return $this->name;
    }
    public function setName($uname){
       $this->name = $uname;
    }
    public function getAge(){
       return $this->age;
    }
    public function setAge($uage){
      $this->age =$uage;
    }
   
   }

   $teacher = new Teacher("Kalid",30);

    echo $teacher->getName();
    echo $teacher->getAge();
    $teacher->setAge(31);

    echo $teacher->getAge();
//print_r($teacher);

?>