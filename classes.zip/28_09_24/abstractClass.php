<?php 

abstract class ParentAnimal{
    public $name;
    abstract public function eat();
    abstract public function sleep($hours);
    final public function walk(){

    }
}

class Cat extends ParentAnimal{

     public function eat(){
       echo "cat eats fish";
    }
     public function sleep($h){

    }

}
 class Cow extends ParentAnimal{
    public function eat(){
        echo "Cow eats grass";
     }
      public function sleep($h){
     }
 }

?>