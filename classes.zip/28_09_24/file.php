<?php 

if (isset($_POST['btn_submit'])) {
   $file= $_FILES['photo'];
  
   if ($file['size'] > 0) {
   
    $name= $file['name'];
    $size= $file['size'];
    $tmp_name= $file ['tmp_name'];
    $type= $file['type'];

   // print_r($file);


    if( $size <= 2*1024*1024){
       if ( 
        $type == "image/png" || 
        $type == "image/jpg" || 
        $type == "image/jpg" ||
        $type == "application/pdf" ||
        $type == "application/msword" 
        ) {
         move_uploaded_file($tmp_name,"img/{$name}");

         if ($type == "application/pdf") {
           echo "<embed src='img/{$name}' type=''>";
         }else{
            echo "<img src='img/{$name}'>";
         }
       }else{
         echo "only image file is allowed";
       }
    }else{
        echo "large file size. max size is 2mb";
    }

   




   }

}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="#" method="post" enctype="multipart/form-data">
        <input type="file" name="photo">
        <button type="submit" name="btn_submit">Submit</button>
       
    </form>
   
</body>
</html>