<?php 

interface IAnimal{
    public function eat();  
    public function sleep();
}
interface IHuman{
   public function talk();
}
interface IHuman2 extends IHuman, IAnimal{
     public function understand();
}
class Animal implements IAnimal{
    public function eat(){

    }  
    public function sleep(){

    }
}

abstract class BaseHuman{
    abstract public function read();
}

class Human extends BaseHuman implements IHuman2{
    public function eat(){

    }  
    public function sleep(){

    }
    public function talk(){

    }
    public function understand()
    {
        
    }

    public function read(){

    }

   
}

$human= new Human();
$human->talk();
$animal= new Animal();

echo $animal instanceof Animal;


?>