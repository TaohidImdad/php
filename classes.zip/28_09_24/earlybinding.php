<?php 
class BaseStudent{
    public static function callStudent(){
        static::read();
    }
    public static function read(){
       echo "Student must read 5 hours";
    }
}
class Student  extends BaseStudent{
    public static function read(){
        echo "Student must read 10 hours form student class";
     }

}

Student::callStudent();
//BaseStudent::callStudent();




?>