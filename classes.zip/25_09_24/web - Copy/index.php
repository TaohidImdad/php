<?php 
include_once("header.php");

include("placeholder.php");

include_once("footer.php");
?>
