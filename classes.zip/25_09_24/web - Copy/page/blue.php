<div>
    this is blue page.
</div>