
<footer> copyright &copy; 2024</footer>
</body>
</html>