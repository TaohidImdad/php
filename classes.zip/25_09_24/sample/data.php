<?php 
if(isset($_GET["sourov"])){
    $file= strtolower($_GET["sourov"]);
    require_once("{$file}.txt");
}




?>