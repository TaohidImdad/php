<?php
include_once("configs/db_config.php");
include_once("studentClass.php");

if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $data = Student::search($id);
}

if (isset($_POST['btnUpdate'])) {
    $id = $_POST["id"];
    $name = $_POST["name"];
    $subject = $_POST["subject"];
    
    $student= new Student($name, $subject);
    $student->update($id);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h3>Update data</h3>
    <form action="" method="post">
        <input type="hidden" name="id" value="<?php echo isset($data) ? $data->id : "" ?>">
        name <br>
        <input type="text" name="name" value="<?php echo isset($data) ? $data->name : "" ?>"><br>
        Subject <br>
        <input type="text" name="subject" value="<?php echo isset($data) ? $data->subject : "" ?>"> <br>

        <input type="submit" value="Udate" name="btnUpdate">
    </form>
</body>

</html>