<?php

class Student
{
 
  public $name;
  public $subject;


  public function __construct($name, $subject)
  {
     $this->name= $name;
     $this->subject= $subject;
  }

  function save()
  {
    global $db;
    $result = $db->query("insert into students (name,subject) values('{$this->name}','{$this->subject}');");
    echo $result;
  }

  function update($id)
  {
    global $db;
    $result = $db->query("update students set name='{$this->name}', subject='{$this->subject}' where id='$id'");
    echo $result;

    if ($result) {
      header("location:manage_student.php");
    }
  }






 public static  function delete($id)
  {
    global $db;
    $result = $db->query("delete from students where id='$id'");

    if ($result) {
      header("location:manage_student.php");
    } else {
      echo "not deletd";
    }
  }

  public static function display()
  {
    global $db;
    $result = $db->query("select * from students");
    $html = " <table border='1'>";
    $html .= "<tr><th>Id</th><th>Name</th><th> subject</th><th>Action</th></tr>";

    while ($row = $result->fetch_object()) {
      $html .= " <tr><td>$row->id</td><td>$row->name</td><td>$row->subject</td>
        <td>
         <a href='edit_student.php?id=$row->id'>Edit</a>|
         <a href='delete_student.php?id=$row->id'>Delete</a>
        </td>
      
      
      </tr>";
    }

    $html .= "</table>";

    echo  $html;
  }

  public static function search($id)
  {
    global $db;
    $result = $db->query("select * from students where id='$id'");
    $data = $result->fetch_object();
    return $data;
  }


  
}


