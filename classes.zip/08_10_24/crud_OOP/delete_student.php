<?php 
include_once("configs/db_config.php");
include_once("studentClass.php");
if (isset($_GET["id"])) {
   $id=$_GET["id"];
   Student::delete($id);
}





?>