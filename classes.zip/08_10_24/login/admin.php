
<?php 
session_start();

if(!($_SESSION["role"] =="admin")){
  header("location:index.php");
}
print_r($_SESSION);
?>
<a href="logout.php">Logout</a>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Back end welcome to admin</h1>
</body>
</html>