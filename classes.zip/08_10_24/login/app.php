<?php 
session_start();

if(!$_SESSION["id"]){
  header("location:index.php");
}
print_r($_SESSION);
?>
<a href="logout.php">Logout</a>