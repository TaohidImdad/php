<?php
include_once("db_config.php");
session_start();
if (isset($_POST['btnLogin'])) {
    $_username = strtolower($_POST["username"]);
    $_password = $_POST["password"];

    global $db;
    $result = $db->query("select users.id, users.name, users.email,roles.name role  from users join roles on users.role_id=roles.id  where users.name='$_username' and  users.password='$_password'");
    $result = $result->fetch_object();
   // print_r($result);
    if ($result) {
        $_SESSION["uname"] = $result->name;
        $_SESSION["id"] =  $result->id;
        $_SESSION["email"] =  $result->email;
        $_SESSION['role'] = $result->role;

        if($result->role == "user") {
            header("location:app.php");
        }else if($result->role == "admin"){
            header("location:admin.php");
        }
    }else{
        echo "wrong username or password";
    }
}


// $password=123456;
// $hash = password_hash($password, PASSWORD_DEFAULT);
// //echo $hashToStoreInDb;
// $isPassCorrect = password_verify($password, $hash);
// echo $isPassCorrect;


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="#" method="post">
        Username <br>
        <input type="text" name="username"> <br>
        Password <br>
        <input type="text" name="password"> <br>
        <button type="submint" name="btnLogin">Login</button>
    </form>
</body>

</html>