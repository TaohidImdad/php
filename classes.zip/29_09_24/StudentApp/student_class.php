<?php 
class Student{
 public $id;
 public $name;
 public $subject;

 public function __construct($uid,$uname,$usubject)
 {
    $this->id= $uid;
    $this->name=$uname;
    $this->subject=$usubject;
 }

// CRUD
// C = Create 
// R = Read 
// U = Update
// D = Delete

public function save(){
    $data="$this->id,$this->name,$this->subject".PHP_EOL;
    file_put_contents("student_data.txt",$data,FILE_APPEND);
    return "success";
}

}

// $student= new Student(1,"Habib","PHP");
// echo $student->save();

?>