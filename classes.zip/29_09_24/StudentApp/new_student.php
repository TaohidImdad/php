<?php
include_once("student_class.php");

if (isset($_POST["btnSubmit"])) {
    $id = $_POST["id"];
    $name = $_POST["name"];
    $subject = $_POST["subject"];

    if ($id != "" && $name != "" && $subject != "") {
        $student = new Student($id, $name, $subject);
        echo  $student->save();
    } else {
        echo "All fields are required";
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Student</title>
</head>

<body>
    <form action="#" method="post">
        Id <br>
        <input type="text" name="id"><br>
        Name <br>
        <input type="text" name="name"><br>
        Subject <br>
        <select name="subject" id="">
            <option value="">Select Subject</option>
            <option value="PHP">PHP</option>
            <option value="JAVA">JAVA</option>
            <option value="C#">C#</option>
        </select> <br> <br>
        <button type="submit" name="btnSubmit">Submit</button>
    </form>
</body>

</html>