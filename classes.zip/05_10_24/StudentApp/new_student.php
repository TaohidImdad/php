<?php
include_once("student_class.php");

if (isset($_POST["btnSubmit"])) {
    // $id = $_POST["id"];
    $name = $_POST["name"];
    $subject = $_POST["subject"];
    $student = new Student($name, $subject);
    $student->save();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Student</title>
</head>
<body>
    <a href="index.php">Manage Student</a> <br>
    <form action="#" method="post">
        Name <br>
        <input type="text" name="name"> 
        Subject <br>
        <select name="subject" id="">
            <option value="">Select Subject</option>
            <option value="PHP">PHP</option>
            <option value="JAVA">JAVA</option>
            <option value="C#">C#</option>
        </select> 
        <button type="submit" name="btnSubmit">Submit</button>
    </form>
</body>

</html>