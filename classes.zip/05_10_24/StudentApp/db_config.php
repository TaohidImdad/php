<?php 
define("SERVER","localhost");
define("USER","root");
define("PASSWORD","");
define("DATABASE","test");
define("PORT",3306);
$db=new mysqli(SERVER,USER,PASSWORD,DATABASE,PORT);

// $student= $db->query("select * from students");
// print_r( $student->fetch_all() );



?>