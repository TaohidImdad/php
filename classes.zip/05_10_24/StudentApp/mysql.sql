-- drop database test2 ;
-- create database if Not exists test2 ;
use test;

-- create table if not exists students(
--     id int primary key auto_increment, 
--     name varchar(100),
--     batch varchar(50)
-- );

-- insert into students( name, batch )values("Salam", "PHP");
drop table if exists students;
create table students(
id int primary key auto_increment,
name varchar(45),
subject varchar(45)
-- gender varchar(10),
-- class varchar(20),
-- roll varchar(45),
-- section varchar(45)
);

-- truncate table students;

insert into students(name,subject)values("Hasan","PHP");
insert into students(name,subject)values("Habib","JAVA");
insert into students(name,subject)values("Masum","C#");
insert into students(name,subject)values("Jamir","C++");
insert into students(name,subject)values("Aslam","PHP");
insert into students(name,subject)values("A Kader","PHP");
insert into students(name,subject)values("Jamal","JAVA");
insert into students(name,subject)values("A Hannan","PHP");
-- insert into students(name,gender,class,roll,section)values("Mahbub","M",1,2,"A");
-- insert into students(name,gender,class,roll,section)values("Jamila","F",1,3,"A");
-- insert into students(name,gender,class,roll,section)values("Khokon","M",1,4,"A");
-- insert into students(name,gender,class,roll,section)values("Maymuna","F",1,5,"A");
-- insert into students(name,gender,class,roll,section)values("Ramisha","F",1,6,"A");
-- insert into students(name,gender,class,roll,section)values("Kabbab","M",1,7,"A");
-- insert into students(name,gender,class,roll,section)values("Monira","F",1,8,"A");

-- update students set name="sojib" where id=1 ;

-- F:/xamp/htdocs/05_10_24/StudentApp/mysql.sql;
