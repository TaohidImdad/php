<?php 

$a=1;

while (++$a < 5) {
    
   // echo $a , "<br>";
    // $a++;
}

// 0
// 1
// 2
// 3
// 4

$a = $b =5;

$a= ++$b;

echo $a , $b

?>