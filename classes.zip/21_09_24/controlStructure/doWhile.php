<?php 

$a =0;
do {
    echo "bangladesh" , "<br>";
    $a++;
} while ($a <= 10);



?>