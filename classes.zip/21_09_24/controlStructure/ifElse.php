<?php

$num=12;
if($num == 10){
    echo "Ten";
}

echo "<br>";

if($num == 10){
    echo "Ten";
}else{
    echo "Not ten";
}

echo "<br>";

if($num == 10){
    echo "Ten";
}elseif($num == 11){
    echo "eleven";
}else{
    echo "other number";
}






?>