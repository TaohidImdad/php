<?php 

// for ($i=1; $i < 11; $i++) { 
//     echo $i;
//     echo "<br>";
// }

// break
// continue 

// for ($i=1; $i < 11; $i++) { 
//     if ( $i > 5) {
//        break;
//     }
//     echo $i;
//     echo "<br>";
// }

for ($i=1; $i < 11; $i++) { 
    if ( $i <= 5) {
       continue;
    }
    if ( $i == 8) {
        continue;
     }
    echo $i;
    echo "<br>";
}

?>