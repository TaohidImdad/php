<?php 
function add($a, $b){
    return $a+$b;
}

function name($data){
   return "My name is {$data}";
}

// type hint 
// fixed return type
function add1(int $a,int $b):int{
    return $a+$b;
}
function name2( string $data):string{
    return "My name is {$data}";
 }

//echo  add(12,6);

$name= "Rashed";
name("Kashem");

$f = function(){
    return "annonymus function"; 
};

//echo $f();

function sayHello($str= "A Halim"){
    return "Hello ".$str;
    //return "Hello {$str}";
}
 //echo sayHello();
 function recursiveData($a){
    if ($a >= 10){
        return;
    }
    echo $a;
    $a++;
     recursiveData($a);
 }
 //recursiveData(1);



 function addNumber(...$numbers){
    $result = 0;
    foreach ($numbers as $key => $number) {
        $result+= $number;
    }

    return $result;
}

//echo  addNumber(5,6,8,10);


function task1(){
    echo "task1";
}

function task2(){
    echo "task2";
}
function task3(){
    echo "task3";
}

function finaltaks(){
    task1();
    task2();
    task3();
}

finaltaks();

?>