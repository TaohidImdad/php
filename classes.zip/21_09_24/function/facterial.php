<?php


function factorial($number){

    if(gettype($number) != "integer"){
        return "invalid data ";
    }
    $result =1;
   
    for(  $abc = $number;  $abc > 1; $abc--){
        $result= $result * $abc;
    }
    return $result;
}

 echo factorial(6);


 

?>