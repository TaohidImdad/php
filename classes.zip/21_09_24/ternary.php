<?php

$age= 50;
$score=12;

$value = ($age == 20) ? 'true':'false';
echo $value1;

// Null Coalescing Operator
$value2 = $age ?? $score;

echo $value2;




?>