<?php 
       
 $color = "red";

  switch($color){
     case "red":
        echo "red is my fevorit color";
        break;
    case "blue":
        echo "blue is my fevorit color";
        break;
    default:
      echo "$color is ok";
  }



?>