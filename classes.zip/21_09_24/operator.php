<?php

// arithmatic operator 

// + - * / % 

// logical operator 
// && || and or not !

// comparison operator 
// < > <= >=  == === != etc 


$n= 88;
$n="88";


// assignment operator 
// = , += *= 






?>