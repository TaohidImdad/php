<?php


$data = true and false;


$data2= true and true;

if($data){
    echo "true";
}else{
    echo "false";
}


// if($data2){
//     echo "true";
// }else{
//     echo "false";
// }



 $num1 =5;
 $num2= 6;

 $result= $num1 <=> $num2;
 
 echo $result;



?>