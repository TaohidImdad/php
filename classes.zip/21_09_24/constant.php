<?php
define("PI", 1.314159);
$pi= constant("PI");
echo "$pi";

