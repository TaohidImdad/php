<?php 

$year = 1900;
if( $year % 4 ==0 && $year % 100==0 &&  $year %400== 0){
    echo "$year is a lipyear";
}elseif($year % 4 ==0 && $year % 100==0){
    echo "$year is not a lipyear";
}elseif($year % 4 ==0 ){
    echo "$year is a lipyear";
}


?>