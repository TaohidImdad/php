<?php 
// include_once("configs/db_config.php");
include_once("configs/db_config_pdo.php");

if (isset($_POST["btnCreate"])) {
    $name=$_POST["name"];
    $subject=$_POST["subject"];
    global $db;
    $result= $db->query("insert into students (name,subject) values('$name','$subject');");
    print_r($result) ; 

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
        name <br>
        <input type="text" name="name"><br>
        Subject <br>
        <input type="text" name="subject"> <br>

        <input type="submit" value="Create" name="btnCreate">
    </form>
</body>
</html>