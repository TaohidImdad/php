
-- get all data
SELECT * FROM TABALENAME;
-- get search data 
SELECT * FROM TABALENAME WHERE id="id";
-- insert data
INSERT INTO TABALENAME(COLUMNNAME1,COLUMNNAME2)VALUES("value1","value2");
-- update data 
UPDATE TABALENAME SET COLUMNNAME1="Value1",COLUMNNAME2="Value2" WHERE id="id";
-- delete data
DELETE FROM TABALENAME WHERE id="id";