<?php 
define("SERVER", "127.0.0.1");
define("USER", "root");
define("PASS", "");
define("DATABASE", "test");
define("PORT", 3306);

// $db = new PDO("mysql:host=".SERVER.";dbname=".DATABASE.";port=".PORT,  USER, PASS);
$db = new PDO("mysql:host=localhost;dbname=test;port=3306",  USER, PASS);
$db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
?>
