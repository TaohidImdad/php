<?php 
define("SERVER", "localhost");
define("USER", "root");
define("PASS", "");
define("DATABASE", "test");
define("PORT", 3306);

$db = new mysqli(SERVER,USER,PASS,DATABASE,PORT);


?>
