<?php 
//  include_once("configs/db_config.php");
 include_once("configs/db_config_pdo.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   
</head>
<body>
    <table border="1">
      <tr> 
        <th>Id</th> 
        <th>Name</th> 
        <th> subject</th>
        <th>Action</th>
    </tr>

    <?php  
     $result = $db->query("select * from students");
     
  

    //  while ($row = $result->fetch_object()) {
     while ($row = $result->fetchObject()) {
       echo " <tr><td>$row->id</td><td>$row->name</td><td>$row->subject</td>
         <td>
          <a href='edit_student.php?id=$row->id'>Edit</a>|
          <a href='delete_student.php?id=$row->id'>Delete</a>
         </td>
       
       
       </tr>";
     }
    
    ?>
    </table>
   
</body>
</html>