<?php 
include_once("configs/db_config.php");
include_once("function.php");
if (isset($_GET["id"])) {
   $id=$_GET["id"];
  //  function delete($id){
  //   global $db;
  //   $result= $db->query("delete from students where id='$id'");
    
  //   if($result){
  //     header("location:manage_student.php");
  //   }else{
  //     echo "not deletd";
  //   }
  // }

  delete($id);
}





?>