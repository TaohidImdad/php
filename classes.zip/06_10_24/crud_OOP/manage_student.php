<?php 
 include_once("configs/db_config.php");

  function display(){
    global $db; 
    $result = $db->query("select * from students");
    $html=" <table border='1'>";
    $html.="<tr><th>Id</th><th>Name</th><th> subject</th><th>Action</th></tr>";

    while ($row = $result->fetch_object()) {
      $html.= " <tr><td>$row->id</td><td>$row->name</td><td>$row->subject</td>
        <td>
         <a href='edit_student.php?id=$row->id'>Edit</a>|
         <a href='delete_student.php?id=$row->id'>Delete</a>
        </td>
      
      
      </tr>";
    }

  $html.="</table>";

   echo  $html;

  }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   
</head>
<body>
  <a href="new_student.php">New Studnet</a>
  <a href="search_student.php">Search Studnet</a>
   <?php 
   
    display();
   
   ?>
   
</body>
</html>