<?php 

function delete($id){
    global $db;
    $result= $db->query("delete from students where id='$id'");
    
    if($result){
      header("location:manage_student.php");
    }else{
      echo "not deletd";
    }
  }


?>