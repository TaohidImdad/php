<?php 
include_once("configs/db_config.php");

if (isset($_POST["btnSearch"])) {
   $id= $_POST['id'];

   function search($id){
    global $db;
    $result = $db->query("select * from students where id='$id'");
    $data= $result->fetch_object();
    return $data;
   }

   $data= search($id);

   if ($data) {
    echo $data->id ."<br>"; 
    echo $data->name ."<br>"; 
    echo $data->subject ."<br>"; 
   }else{
     echo "data not found";
   }


}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="#" method="post">
        <input type="text" name="id"> 
        <input type="submit" value="search" name="btnSearch">
    </form>
</body>
</html>