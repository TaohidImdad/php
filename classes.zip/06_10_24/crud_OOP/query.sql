
-- get all data
SELECT * FROM TABALENAME;
-- get search data 
SELECT * FROM TABALENAME WHERE id="id";
-- insert data
INSERT INTO TABALENAME(COLUMNNAME1,COLUMNNAME2)VALUES("value1","value2");
-- update data 
UPDATE TABALENAME SET COLUMNNAME1="Value1",COLUMNNAME2="Value2" WHERE id="id";
-- delete data
DELETE FROM TABALENAME WHERE id="id";-

table user
id
Name 
Email 
Password 
role  


1 Jamal jamal@gmail.com 12345 admin
2 Habib habib@gmial.com 32156 user
