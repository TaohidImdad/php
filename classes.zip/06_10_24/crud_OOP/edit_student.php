<?php 
include_once("configs/db_config.php");

if (isset($_GET["id"])) {
    $id=$_GET["id"];
    // global $db;
    // $result = $db->query("select * from students where id='$id'");
    // $data= $result->fetch_object();
    //print_r( $data);

    function search($id){
        global $db;
        $result = $db->query("select * from students where id='$id'");
        $data= $result->fetch_object();
        return $data;
       }

   $data= search($id);

}

if(isset($_POST['btnUpdate'])){
   $id=$_POST["id"];
   $name=$_POST["name"];
   $subject=$_POST["subject"];
  
   function update($id, $name,$subject){
    global $db;
    $result= $db->query("update students set name='$name', subject='$subject' where id='$id'");
    echo $result;
 
     if($result){
         header("location:manage_student.php");
     }
   }
  
//    global $db;
//    $result= $db->query("update students set name='$name', subject='$subject' where id='$id'");
//    echo $result;

//     if($result){
//         header("location:manage_student.php");
//     }

 update($id, $name,$subject);

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>Update data</h3>
    <form action="" method="post">
        <input type="hidden" name="id" value="<?php echo isset($data)? $data->id :""?>">
        name <br>
        <input type="text" name="name" value="<?php echo isset($data)? $data->name :""?>"><br>
        Subject <br>
        <input type="text" name="subject" value="<?php echo isset($data)? $data->subject :""?>"> <br>

        <input type="submit" value="Udate" name="btnUpdate">
    </form>
</body>
</html>