<?php
$fname= "Rashed";
$data= sprintf("my name is %s", $fname);
echo $data;



?>