<?php

 //$name= "hasan";
 $lastname="habib";
 
 /*$name= "hasan";
 $lastname="habib"; */

 #$lastname="habib";


?>