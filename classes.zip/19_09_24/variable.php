<?php 

// meaningfull name

// $firstname="name";
// $first_name;
// $firstName;
// $FirstName;

 $lastname= "Habib";
function name(){
    global $lastname;
    //$GLOBALS['lastname'];
    echo $lastname;
}
//echo $lastname;
name();

?>