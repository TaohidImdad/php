<?php
$name="banglades";
$fname="Younus";
printf("We love %s . our primeminister is %s. his age is %d",  ucfirst($name), $fname, 86);

$hexadecimal=0x2b;
$octal=056;
$decimal=456;

printf("the hexadecimal convert to  %d ", $octal);

echo "<br>";
$fname= "Rashed";
$lname= "khan";
printf('My name is %2$s %1$s', $lname, $fname);



?>