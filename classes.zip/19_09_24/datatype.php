<?php
// int
$integer=456;
// double /float 
$doubledata= 12.5;

// boolian 
$booldata= true;
$booldata= false;
$booldata= 0;
$booldata= 1;
$booldata= "s";

// string 
$name="Salam";

// null 

$lastname= null;

// array 
$arr= ['apple', 'banana'];

// object 

//$obj= new Class();

var_dump($name);


?>