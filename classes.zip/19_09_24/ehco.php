<?php
$name= "Bangladesh";
$fname= "Younus";
echo "Hello world";
echo "<br>";
echo "$name $fname";
echo "<br>";
echo "i love {$name}";
echo "<br>";
echo 'i love {$name}';
echo "<br>";

$pic="nature";
echo "{$pic}_.jpg"

?>