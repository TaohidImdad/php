<?php

$num=0;

$result= $num % 2;

//echo $result;

if($result == 0 ){
    if($num > 0){
        echo "positive even number";
    }else{
        echo "nagative even number";
    }
}else{
    if($num > 0){
        echo "positive odd number";
    }else{
        echo "nagative odd number";
    }
}

?>