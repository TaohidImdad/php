DDL  create , drop, alter , rename
DML  insert , update , delete , limit etc
DCL  grant revoke 
TCL  bigin commit rollback