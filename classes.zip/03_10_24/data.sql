-- drop database test2 ;
-- create database if Not exists test2 ;
use test;

create table if not exists students(
    id int primary key auto_increment, 
    name varchar(100),
    batch varchar(50)
);

insert into students( name, batch )values("Salam", "PHP");