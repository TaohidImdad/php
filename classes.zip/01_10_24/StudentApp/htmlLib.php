<?php  
function actionButton($props){
 $html="
    <form style='float:left;' action='{$props['action']}' method='post'>
    <input type='hidden' name='id' value='{$props['id']}'>
    <button type='submit' name='{$props['btnName']}' >{$props['button']}</button>
   </form>
 ";

  return $html;
}



?>