<?php 
include_once("student_class.php");
include_once("htmlLib.php");


if (isset($_POST["btnDelete"])) {
   $id=$_POST['id'];
   if ($id != "") {
    echo Student::delete($id);
   }
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students</title>
    <style>
        table,tr,th,td{
            border: 1px solid gray;
            border-collapse: collapse;
        }
        th,td{
            padding: 10px;
        }
        tr:nth-child(even){
            background-color: lightgray;
        }
    </style>
</head>
<body>
    <a target="_blank" href="new_student.php">New Student</a>
    <?php 
    echo Student::dispaly();
    ?>
</body>
</html>