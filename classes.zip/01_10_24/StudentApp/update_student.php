<?php 
include_once("student_class.php");
 if (isset($_POST["btnEdit"])) {
   $id= $_POST['id'];
   if ( $id != "") {
     $data = Student::search($id);
     $data=$data[0];

    // print_r( $data);
     $id=isset($data['id']) ?$data['id'] :"" ;
     $name=isset($data['name']) ?$data['name'] :"" ;
     $subject = isset($data['subject']) ? $data['subject'] :"" ;
   }
 }


 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="#" method="post">
        Id <br>
        <input value="<?php echo $id ?>" type="text" name="id"> <br>
        Name <br>
        <input value="<?php echo $name ?>" type="text" name="name"> <br>
        Subject <br>
        <select name="subject" id="">
            <option  <?php echo (trim($subject) == "PHP") ? "selected": ""; ?> value="PHP">PHP</option>
            <option  <?php echo (trim($subject) == "JAVA") ? "selected": "" ;?> value="JAVA">JAVA</option>
            <option <?php echo  (trim($subject) == "C#") ? "selected": "" ;?> value="C#">C#</option>
        </select>   <br> <br>
        <button type="submit" name="btnSubmit">Submit</button>
    </form>
</body>
</html>