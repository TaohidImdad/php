<?php 
// http verb  GET POST PUT PATCH DELETE
//query string 

if(isset($_GET['btnSubmit'])){
  
  
    $number1 = $_GET["num1"];
    $number2 = $_GET["num2"];
    $number3 = $_GET["num3"];
  



    if($number1 > $number2){
        if ($number1 > $number3) {
            echo "Number $number1 is the max number among $number1 , $number2, $number3";
        } else {
            echo "Number $number3 is the max number among $number1 , $number2, $number3";
        }
        
    }else if($number2 > $number1){

        if ($number2 > $number3) {
            echo "Number $number2 is the max number among $number1 , $number2, $number3";
        } else {
            echo "Number $number3 is the max number among $number1 , $number2, $number3";
        }

    }


}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
</head>
<body>
    <form action="#" method="GET">
         First Number <br>
        <input type="text" name="num1"> <br>
         Second Number<br>
        <input type="text" name="num2"><br>
         Third Number<br>
        <input type="text" name="num3"><br>

        <button name="btnSubmit" type="submit">Submit</button>
    </form>
</body>
</html>