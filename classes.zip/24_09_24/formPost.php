<?php 
// http verb  GET POST PUT PATCH DELETE
// Post Method

if(isset($_POST['btnSubmit'])){
  $name = $_POST["name1"];
  $email = $_POST["email1"];

  echo $name."<br>";
  echo $email."<br>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
</head>
<body>
    <form action="#" method="POST">
        User name <br>
        <input type="text" name="name1"> <br>
        Email <br>
        <input type="text" name="email1"><br>
        <button name="btnSubmit" type="submit">Submit</button>
    </form>
</body>
</html>