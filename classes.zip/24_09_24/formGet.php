<?php 
// http verb  GET POST PUT PATCH DELETE
//query string 

if(isset($_GET['btnSubmit'])){
  $name = $_GET["name1"];
  $email = $_GET["email1"];
  $password= $_GET['password'];

  echo $name."<br>";
  echo $email."<br>";
  echo $password."<br>";
}
 $students= [ "Dkaha"=>"Hakim", "Pabna"=>"Jabbar", "Barishal"=>"Rasel"];
 echo $students["Barishal"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
</head>
<body>
    <form action="#" method="GET">
        User name <br>
        <input type="text" name="name1"> <br>
        Email <br>
        <input type="text" name="email1"><br>
        <button name="btnSubmit" type="submit">Submit</button>
    </form>
</body>
</html>