<?php 
// $GLOBALS
// $_SERVER
// $_REQUEST
// $_POST
// $_GET
// $_FILES
// $_ENV
// $_COOKIE
// $_SESSION


 $name = "Bangladesh";


  function sayHello(){
      global $name;
     echo "Hi $name";
  }
  sayHello();








?>