<?php 
$capitals= ["Bangladesh"=>"Dhaka", "india"=> "Noya Dhilhi", "Pakistan"=>"Islamabad"];
$names=["Salam","Borkot","Jabbar", "Hakim"];

 $capitals= serialize($capitals);
 $flow2= unserialize( $capitals);
print_r( $flow2);

// $name= json_encode($capitals);
// $name= json_decode($name, true);
// print_r($name);


// $flow3= json_encode($capitalsames);
// $flow3= json_decode($flow3,true);


?>