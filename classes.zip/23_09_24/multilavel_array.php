<?php 
//  $numbers=[
//     [1,5,6,7],
//     [56,33,22,11],
//     [55,77,88,99,[1,"007"]],
//  ];

//   print_r($numbers);
//   echo $numbers[1][2];
//   echo $numbers[2][4][1];

// $user[1]="Rafiq";
// $user[2]="shafiq";
// $user[3]="Nasir";
// $user[4]="Hasan";

// print_r($user);

$foods=[
    "Fish"=> "Rui , Ilish, Pangash, Tengra",
    "Fruits"=> "Mango , Orenge, Lichi, banana",
    "Vegitables"=> "Potato , Brinjal, Carrot, Cukamber",
];

$foods2=[
    "Fish"=> explode(", ","Rui, Ilish, Pangash, Tengra"),
    "Fruits"=> explode(", ", "Mango, Orenge, Lichi, banana") ,
    "Vegitables"=> ["Potato", "Brinjal", "Carrot", "Cukamber"],
];

 $fish=   explode(",","Rui, Ilish, Pangash, Tengra");
// $foods['Fish']=$foods['Fish'].", Boal";

// echo $foods2['Fish'][3];

// print_r($foods2);

$city=["dhaka","london","Makkah"];

$range = range(20,25);

print_r($range);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <p>  <?php  echo  join(" ,", $city);  ?>  </p>


    <form action="">
        <label for="">City</label>
        <select name="city" id="">
            <?php 
             foreach ($city as $key => $value) {
               echo "<option value=\" $value\">$value</option>";
             }
            
            
            ?>
           
        </select>
    </form>
</body>
</html>