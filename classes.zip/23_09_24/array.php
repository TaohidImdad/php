<?php 
// index array 
$names=["Salam","Borkot","Jabbar", "Hakim"];
$fruits= array("Mango", "banana","Lichi");


// echo $names[3];
// echo $names[1];
// print_r($names[1]);


//print_r($names);
//print_r($fruits);

// associatiove array 
$capitals= ["Bangladesh"=>"Dhaka", "india"=> "Noya Dhilhi", "Pakistan"=>"Islamabad"];
$capitals2= array("Bangladesh"=>"Dhaka", "india"=> "Noya Dhilhi", "Pakistan"=>"Islamabad");

//print_r($capitals2);
//echo $capitals;

//echo $capitals["india"];
// echo $names[1];
// print_r($names[1]);

// check array
// if(is_array($names[1])){
//     echo "this is an array";
// }else{
//     echo "this is not an array";
// }

// number of elements 
$arrayElements= count($names);
//echo $arrayElements;



// for ($i=0; $i < 4 ; $i++) {
//     echo "{$names[$i]} <br>";
// }

//echo $names[3]

foreach ($capitals as $i => $value){
    //echo" {$i} = {$value} "."<br>";
}

$keys= array_keys($capitals);
//print_r($keys[1]);

$arrCount= count($capitals);
for ($i=0; $i < $arrCount ; $i++) { 
    echo "$keys[$i] =". $capitals[ $keys[$i]]."<br>";
}

?>