<?php 
$names=["Salam","Borkot","Jabbar", "Hakim"];

 //print_r($names);

 $names[]="Kashem";

 $names[3]="Rafiq";

 array_push($names, "Khalid");
 array_unshift($names, "Nasir");


//  print_r($names);
//  array_pop($names);
//  print_r($names);
 print_r($names);
 array_shift($names);
 print_r($names);

 

?>