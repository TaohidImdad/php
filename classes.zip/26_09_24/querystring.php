<?php 

include_once("lib.php");

  if(isset($_GET['a'])){

  $a=$_GET['a']; 
  $b=$_GET['b']; 
  $c=$_GET['c']; 

  $Objlib= new Lib();


   //echo  $Objlib -> facterial($a);
    //echo  $Objlib -> primeNumber($a) ? "Prime Number" : "Not a prime Number" ;
    echo  $Objlib -> minMax($a,$b,$c);
  }

 ?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
 </head>
 <body>
    <form action="" method="get">
        value a <br>
        <input type="text" name="a"> <br>
         value b <br>
         <input type="text" name="b"><br>
         value c <br>
         <input type="text" name="c"> <br>
         <button type="submit">submit</button>


    </form>
 </body>
 </html>