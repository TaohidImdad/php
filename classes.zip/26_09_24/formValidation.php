<?php 

// include_once("lib.php");

  if(isset($_GET['submit'])){
  $name = $_GET['uname'];
  $email = $_GET['uemail'];
  $password = $_GET['password'];

  $error = [];
 
    // Rashed
   $namePattern= '/^(@)[a-zA-Z]{4,8}$/';

   $emailPattern= '/^[a-zA-Z]{4,}[@][a-z]{3,}[.][a-z]{2,3}$/';

   $passwordPattern= '/^[a-zA-Z]{4,8}$/';

   if(!preg_match($namePattern,$name)){
    $error['name']= "Invalid Name";
   }
   if(!preg_match($emailPattern,$email)){
 
    $error["email"]= "Invalid Email";
   }
   if(!preg_match($passwordPattern,$password)){
    $error["password"]= "Invalid Password";

   }
   

  }




 //print_r( $error);
 

 ?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
 </head>
 <body>
    <form action="#" method="get">
        
         Name <br>
        <input type="text" name="uname" value="<?php echo isset($name) ? $name :""; ?>"   > <?php echo  isset($error['name']) ? $error['name']:""; ?> <br>
         Email <br>
         <input type="text" name="uemail" value="<?php echo isset($email) ? $email :""; ?>"> <?php echo  isset($error['email'])? $error['email']:"";  ?> <br>
          Password <br>
         <input type="text" name="password" value="<?php echo isset($password) ? $password :""; ?>"> <?php echo  isset($error['password']) ? $error['password']:"";  ?> <br>
         <button name="submit" type="submit">submit</button>


    </form>
 </body>
 </html>