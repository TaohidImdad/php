<?php 

if (isset($_GET['page'])) {

    $page= $_GET['page'];
    
    if($page != ""){
        include("page/{$_GET['page']}.php"); 
    }else{
        include("page/home.php");
    }
}else{
    include("page/home.php");
}


?>