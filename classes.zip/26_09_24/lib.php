<?php

class Lib
{
     function facterial($a)
    {
        $result = 1;
        for ($i = 1; $i <= $a; $i++) {
            $result = $result * $i;
        }

        return $result;
    }

    function primeNumber($a)
    {
        for ($i = 2; $i < $a; $i++) {
            if ($a % $i == 0) {
                return false;
            }
        }
        return true;
    }

    function minMax($a, $b, $c)
    {
        if ($a > $b) {
            if ($a > $c) {
                echo " $a is Max number";
            } else {
                echo " $c is Max number";
            }
        } elseif ($b > $a) {
            if ($b > $c) {
                echo " $b is Max number";
            } else {
                echo " $c is Max number";
            }
        }
    }
}
