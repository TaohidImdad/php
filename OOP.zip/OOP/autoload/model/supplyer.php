<?php 
namespace Model;
class Supplyer{
    function __construct(){
          echo "hell0 supplier <br>";
    }
}




?>