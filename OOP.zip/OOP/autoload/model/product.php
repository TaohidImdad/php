<?php 
namespace Model;   
class Product{
    function __construct(){
          echo "hell0 product <br>";
    }
}




?>