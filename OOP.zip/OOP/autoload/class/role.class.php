<?php 
namespace ClassFolder;
class Role{
    function __construct(){
          echo "hell0 role <br>";
    }
}




?>