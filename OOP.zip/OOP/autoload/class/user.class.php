<?php 
namespace Autoload\ClassFolder;
class User{
    function __construct(){
          echo "hell0 user <br>";
    }
}




?>