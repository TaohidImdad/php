<?php
  
 function add($data){
     echo $data["a"]+$data["b"];
 }

 function sub($data){
   echo $data["a"]-$data["b"];
 }

 function mul($data){
   echo $data["a"]*$data["b"];
 }

 function div($data){
   echo $data["a"]/$data["b"];
 }


?>