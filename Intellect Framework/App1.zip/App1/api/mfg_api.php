<?php
function get_manufacturers($data){
   echo Manufacturer::get_manufacturers_json();
}
?>